const header = document.querySelector("[data-header]");
const headerBrand = document.querySelector(".site-header .brand");
const menuButton = document.querySelector("[data-menu-button]");
const navLinks = document.querySelector("[data-nav-links]");
const navSubmenuItems = [...document.querySelectorAll("[data-nav-item]")];
const navNestedItems = [...document.querySelectorAll("[data-nav-nested-item]")];
const navZoneGroups = [...document.querySelectorAll("[data-nav-zone-group]")];
const mobileNavigation = window.matchMedia("(max-width: 1200px)");
const contactForm = document.querySelector("[data-contact-form]");
const heroLogo = document.querySelector(".hero-brand-stage");
const year = document.querySelector("[data-year]");
const faqButtons = [...document.querySelectorAll("[data-faq-trigger]")];
const carouselImageSets = {
  chantier: [
    {
      src: "../assets/suivi-chantier-01.jpg",
      alt: "Vue aérienne verticale d'un chantier en excavation à Montréal"
    },
    {
      src: "../assets/suivi-chantier-02.webp",
      alt: "Vue rapprochée d'un chantier avec travailleurs et excavation"
    },
    {
      src: "../assets/suivi-chantier-03-dji0135.jpg",
      alt: "Vue aérienne d'un chantier commercial captée par drone"
    }
  ],
  inspection: [
    {
      src: "../assets/inspection-facade-01.jpg",
      alt: "Vue détaillée d'une façade inspectée par drone"
    },
    {
      src: "../assets/inspection-toiture-01.jpg",
      alt: "Vue aérienne verticale d'une toiture inspectée par drone"
    }
  ]
};
const motionTextSelector = [
  "main h1",
  "main h2",
  "main h3",
  "main p",
  "main li",
  "main .button",
  "main .eyebrow",
  "main .project-content span",
  "main .project-details span",
  "main .hero-meta strong",
  "main .hero-meta span"
].join(",");
const firstPageSection = document.querySelector("main > section");
const motionTextElements = [...document.querySelectorAll(motionTextSelector)]
  .filter((element) => !firstPageSection?.contains(element) && !element.closest(".hero-brand-stage") && !element.closest(".faq-section") && !element.closest(".case-faq") && !element.matches("[data-form-status]"));

if (window.location.protocol === "file:") {
  document.querySelectorAll("a[href]").forEach((link) => {
    const target = new URL(link.href);
    if (target.protocol === "file:" && target.pathname.endsWith("/")) {
      target.pathname += "index.html";
      link.setAttribute("href", target.href);
    }
  });
}

if (year) {
  year.textContent = new Date().getFullYear();
}

const initMediaLoadingStates = () => {
  const mediaElements = [...document.querySelectorAll("img, video, iframe")];
  const excludedSelectors = [
    ".site-header",
    ".site-footer",
    ".partner-widget",
    ".hero-brand-stage",
    ".securi-hero-title-logo",
    ".prototype-topbar",
    ".securi-topbar"
  ].join(",");

  mediaElements.forEach((media) => {
    if (media.closest(excludedSelectors) || media.closest(".media-loader-wrap")) {
      return;
    }

    const existingFrame = media.closest("[data-video-sequence], .video-embed, .case-video-frame, .project-video-frame, .securi-carousel-slide");
    const target = media.parentElement?.tagName === "PICTURE" ? media.parentElement : media;
    const parent = target.parentNode;
    let wrapper = existingFrame;

    if (!wrapper && !parent) {
      return;
    }

    if (wrapper) {
      wrapper.classList.add("media-loader-wrap", "media-loading");
    } else {
      wrapper = document.createElement("span");
      wrapper.className = "media-loader-wrap media-loading";
      parent.insertBefore(wrapper, target);
      wrapper.appendChild(target);
    }

    wrapper.setAttribute("aria-busy", "true");

    const markLoaded = () => {
      wrapper.classList.remove("media-loading");
      wrapper.classList.add("media-loaded");
      wrapper.setAttribute("aria-busy", "false");
    };

    if (media.tagName === "IMG") {
      if (media.complete && media.naturalWidth > 0) {
        markLoaded();
        return;
      }

      media.addEventListener("load", markLoaded, { once: true });
      media.addEventListener("error", markLoaded, { once: true });
      return;
    }

    if (media.tagName === "VIDEO") {
      if (media.readyState >= 2) {
        markLoaded();
        return;
      }

      media.addEventListener("loadeddata", markLoaded, { once: true });
      media.addEventListener("canplay", markLoaded, { once: true });
      media.addEventListener("error", markLoaded, { once: true });
      return;
    }

    media.addEventListener("load", markLoaded, { once: true });
    media.addEventListener("error", markLoaded, { once: true });
    window.setTimeout(markLoaded, 12000);
  });
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initMediaLoadingStates, { once: true });
} else {
  initMediaLoadingStates();
}

document.querySelectorAll("[data-carousel]").forEach((carousel) => {
  const image = carousel.querySelector("[data-carousel-image]");
  const previousButton = carousel.querySelector("[data-carousel-prev]");
  const nextButton = carousel.querySelector("[data-carousel-next]");
  const carouselImages = carouselImageSets[carousel.dataset.carousel] || carouselImageSets.chantier;
  let currentIndex = 0;

  const setCarouselImage = (direction) => {
    if (!image) {
      return;
    }

    currentIndex = (currentIndex + direction + carouselImages.length) % carouselImages.length;
    carousel.classList.add("is-changing");

    window.setTimeout(() => {
      const loader = image.closest(".media-loader-wrap");
      if (loader) {
        loader.classList.add("media-loading");
        loader.classList.remove("media-loaded");
        loader.setAttribute("aria-busy", "true");
        image.addEventListener("load", () => {
          loader.classList.remove("media-loading");
          loader.classList.add("media-loaded");
          loader.setAttribute("aria-busy", "false");
        }, { once: true });
      }

      image.removeAttribute("srcset");
      image.removeAttribute("sizes");
      image.src = carouselImages[currentIndex].src;
      image.alt = carouselImages[currentIndex].alt;
      carousel.classList.remove("is-changing");
    }, 130);
  };

  if (previousButton) {
    previousButton.addEventListener("click", () => setCarouselImage(-1));
  }

  if (nextButton) {
    nextButton.addEventListener("click", () => setCarouselImage(1));
  }
});

document.querySelectorAll("[data-video-sequence]").forEach((frame) => {
  const sources = frame.dataset.videoSequence.split("|").filter(Boolean);
  const firstVideo = frame.querySelector("video");
  let currentVideoIndex = 0;
  let isSwitching = false;
  const transitionLeadTime = 1;

  if (!firstVideo || sources.length < 2) {
    return;
  }

  const sequenceVideos = sources.map((source, index) => {
    const video = index === 0 ? firstVideo : firstVideo.cloneNode(false);
    video.src = source;
    video.muted = true;
    video.playsInline = true;
    video.preload = "metadata";
    video.loop = false;
    video.setAttribute("muted", "");
    video.setAttribute("playsinline", "");
    video.setAttribute("preload", "metadata");

    if (index > 0) {
      video.classList.remove("is-active");
      frame.appendChild(video);
      video.load();
    }

    return video;
  });

  const switchToVideo = (nextVideoIndex) => {
    const currentVideo = sequenceVideos[currentVideoIndex];
    const nextVideo = sequenceVideos[nextVideoIndex];
    let fallbackTimer;
    let hasShownNextVideo = false;

    isSwitching = true;
    nextVideo.currentTime = 0;

    const showNextVideo = () => {
      if (hasShownNextVideo) {
        return;
      }

      hasShownNextVideo = true;
      window.clearTimeout(fallbackTimer);
      nextVideo.removeEventListener("playing", showNextVideo);
      nextVideo.removeEventListener("canplay", showNextVideo);
      nextVideo.classList.add("is-active");
      currentVideo.classList.remove("is-active");

      window.setTimeout(() => {
        currentVideo.pause();
        currentVideo.currentTime = 0;
        currentVideoIndex = nextVideoIndex;
        isSwitching = false;
      }, 160);
    };

    nextVideo.addEventListener("playing", showNextVideo, { once: true });
    nextVideo.addEventListener("canplay", showNextVideo, { once: true });
    nextVideo.play().then(() => {
      if (nextVideo.readyState >= 2) {
        window.requestAnimationFrame(showNextVideo);
      }
    }).catch(() => {});

    fallbackTimer = window.setTimeout(() => {
      if (nextVideo.readyState < 2) {
        return;
      }

      showNextVideo();
    }, 700);

    window.setTimeout(() => {
      if (!isSwitching || currentVideoIndex !== sequenceVideos.indexOf(currentVideo)) {
        return;
      }

      showNextVideo();
    }, 1200);
  };

  sequenceVideos.forEach((video, index) => {
    video.addEventListener("timeupdate", () => {
      if (isSwitching || index !== currentVideoIndex || !Number.isFinite(video.duration) || video.duration <= 0) {
        return;
      }

      if (video.duration - video.currentTime <= transitionLeadTime) {
        switchToVideo((index + 1) % sequenceVideos.length);
      }
    });

    video.addEventListener("ended", () => {
      if (!isSwitching && index === currentVideoIndex) {
        switchToVideo((index + 1) % sequenceVideos.length);
      }
    });

  });

  const playVisibleSequence = () => {
    sequenceVideos.forEach((video) => {
      if (video.preload !== "auto") {
        video.preload = "auto";
        video.setAttribute("preload", "auto");
        video.load();
      }
    });

    sequenceVideos[currentVideoIndex].play().catch(() => {});
  };

  const pauseHiddenSequence = () => {
    sequenceVideos.forEach((video) => video.pause());
  };

  if ("IntersectionObserver" in window) {
    const videoObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          playVisibleSequence();
        } else {
          pauseHiddenSequence();
        }
      });
    }, { rootMargin: "160px 0px", threshold: 0.2 });

    videoObserver.observe(frame);
  } else {
    playVisibleSequence();
  }
});

motionTextElements.forEach((element) => element.classList.add("text-clarify"));

const clarifyHeroLogo = () => {
  if (!heroLogo || heroLogo.classList.contains("is-clarifying")) {
    return;
  }

  heroLogo.classList.remove("is-fading");
  void heroLogo.offsetWidth;
  heroLogo.classList.add("is-clarifying");
};

const fadeHeroLogo = () => {
  if (!heroLogo || heroLogo.classList.contains("is-fading")) {
    return;
  }

  heroLogo.classList.remove("is-clarifying");
  void heroLogo.offsetWidth;
  heroLogo.classList.add("is-fading");
};

const setHeroLogoState = () => {
  if (!heroLogo) {
    return;
  }

  const logoBox = heroLogo.getBoundingClientRect();
  const isLogoInView = logoBox.bottom > 0 && logoBox.top < window.innerHeight * 0.72;

  if (window.scrollY > window.innerHeight * 0.32) {
    fadeHeroLogo();
  } else if (isLogoInView) {
    clarifyHeroLogo();
  }
};

const clarifyText = (element) => {
  if (element.classList.contains("is-clarifying")) {
    return;
  }

  void element.offsetWidth;
  element.classList.add("is-clarifying");
};

const setMotionTextState = () => {
  motionTextElements.forEach((element) => {
    const box = element.getBoundingClientRect();
    const isVisible = box.bottom > window.innerHeight * 0.08 && box.top < window.innerHeight * 0.88;

    if (isVisible) {
      clarifyText(element);
    }
  });
};

const closeNestedNavMenus = (exception = null) => {
  navNestedItems.forEach((item) => {
    if (item === exception) {
      return;
    }

    item.classList.remove("is-open");
    item.querySelector("[data-nav-nested-toggle]")?.setAttribute("aria-expanded", "false");
  });
};

const closeNavZoneGroups = (exception = null) => {
  navZoneGroups.forEach((group) => {
    if (group === exception) {
      return;
    }

    group.classList.remove("is-open");
    group.querySelector("[data-nav-zone-toggle]")?.setAttribute("aria-expanded", "false");
  });
};

const closeMenu = () => {
  if (navLinks && menuButton) {
    closeNestedNavMenus();
    navSubmenuItems.forEach((item) => {
      item.classList.remove("is-open");
      const toggle = item.querySelector("[data-nav-submenu-toggle]");
      toggle?.setAttribute("aria-expanded", "false");
      toggle?.setAttribute("aria-label", toggle.getAttribute("aria-label").replace("Fermer", "Ouvrir"));
    });
    navLinks.classList.remove("is-open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Ouvrir le menu");
    document.body.classList.remove("menu-open");
  }
};

const closeNavSubmenus = (exception = null) => {
  closeNestedNavMenus();
  navSubmenuItems.forEach((item) => {
    if (item === exception) {
      return;
    }

    item.classList.remove("is-open");
    const toggle = item.querySelector("[data-nav-submenu-toggle]");
    toggle?.setAttribute("aria-expanded", "false");
    toggle?.setAttribute("aria-label", toggle.getAttribute("aria-label").replace("Fermer", "Ouvrir"));
  });
};

mobileNavigation.addEventListener("change", closeMenu);

navNestedItems.forEach((item) => {
  const toggle = item.querySelector("[data-nav-nested-toggle]");

  toggle?.addEventListener("click", () => {
    const willOpen = !item.classList.contains("is-open");
    closeNestedNavMenus(item);
    if (!willOpen) {
      closeNavZoneGroups();
    }
    item.classList.toggle("is-open", willOpen);
    toggle.setAttribute("aria-expanded", String(willOpen));
  });
});

navZoneGroups.forEach((group) => {
  const toggle = group.querySelector("[data-nav-zone-toggle]");
  const containsCurrentPage = Boolean(group.querySelector("a.is-active"));

  if (containsCurrentPage) {
    group.classList.add("is-open");
    toggle?.setAttribute("aria-expanded", "true");
  }

  toggle?.addEventListener("click", () => {
    const willOpen = !group.classList.contains("is-open");
    closeNavZoneGroups(group);
    group.classList.toggle("is-open", willOpen);
    toggle.setAttribute("aria-expanded", String(willOpen));
  });
});

navSubmenuItems.forEach((item) => {
  const toggle = item.querySelector("[data-nav-submenu-toggle]");
  const primaryLink = item.querySelector(".nav-primary-link");

  if (!toggle) {
    return;
  }

  let closeTimer;

  const setExpanded = (expanded) => {
    window.clearTimeout(closeTimer);
    if (expanded) {
      closeNavSubmenus(item);
    }
    item.classList.toggle("is-open", expanded);
    toggle.setAttribute("aria-expanded", String(expanded));
    toggle.setAttribute("aria-label", toggle.getAttribute("aria-label").replace(expanded ? "Ouvrir" : "Fermer", expanded ? "Fermer" : "Ouvrir"));
  };

  toggle.addEventListener("click", () => setExpanded(!item.classList.contains("is-open")));

  item.addEventListener("mouseenter", () => {
    if (!mobileNavigation.matches) {
      setExpanded(true);
    }
  });

  item.addEventListener("mouseleave", () => {
    if (!mobileNavigation.matches && !item.contains(document.activeElement)) {
      closeTimer = window.setTimeout(() => {
        if (!mobileNavigation.matches && !item.matches(":hover") && !item.contains(document.activeElement)) {
          setExpanded(false);
        }
      }, 220);
    }
  });

  primaryLink?.addEventListener("click", (event) => {
    event.preventDefault();
    if (mobileNavigation.matches) {
      toggle.click();
    } else {
      setExpanded(true);
    }
  });
});

if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("is-open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.setAttribute("aria-label", isOpen ? "Fermer le menu" : "Ouvrir le menu");
    document.body.classList.toggle("menu-open", isOpen);

    if (isOpen) {
      window.setTimeout(() => {
        navLinks.querySelector("a")?.focus({ preventScroll: true });
      }, 0);
    }
  });

  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      if (mobileNavigation.matches && link.classList.contains("nav-primary-link")) {
        return;
      }

      closeMenu();
    });
  });

  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") {
      return;
    }

    const openSubmenu = navSubmenuItems.find((item) => item.classList.contains("is-open"));

    if (openSubmenu) {
      const toggle = openSubmenu.querySelector("[data-nav-submenu-toggle]");
      closeNavSubmenus();
      toggle?.focus({ preventScroll: true });
    } else if (navLinks.classList.contains("is-open")) {
        closeMenu();
        menuButton.focus({ preventScroll: true });
    }
  });

  document.addEventListener("click", (event) => {
    if (!event.target.closest("[data-nav-item]")) {
      closeNavSubmenus();
    }
  });
}

faqButtons.forEach((button) => {
  const answer = document.getElementById(button.getAttribute("aria-controls"));

  if (!answer) {
    return;
  }

  button.addEventListener("click", () => {
    const isOpen = button.getAttribute("aria-expanded") === "true";
    button.setAttribute("aria-expanded", String(!isOpen));
    answer.hidden = isOpen;
  });
});

document.querySelectorAll("[data-auto-carousel]").forEach((carousel) => {
  const slides = Array.from(carousel.querySelectorAll("[data-auto-slide]"));

  if (slides.length < 2) {
    return;
  }

  let currentSlide = Math.max(0, slides.findIndex((slide) => slide.classList.contains("is-active")));

  if (!slides[currentSlide]) {
    currentSlide = 0;
    slides[0].classList.add("is-active");
  }

  const setCarouselState = () => {
    const previousSlide = (currentSlide - 1 + slides.length) % slides.length;
    const nextSlide = (currentSlide + 1) % slides.length;

    slides.forEach((slide, index) => {
      slide.classList.toggle("is-active", index === currentSlide);
      slide.classList.toggle("is-prev", index === previousSlide);
      slide.classList.toggle("is-next", index === nextSlide);
    });
  };

  setCarouselState();

  window.setInterval(() => {
    currentSlide = (currentSlide + 1) % slides.length;
    setCarouselState();
  }, 5000);
});

window.addEventListener("scroll", () => {
  setHeroLogoState();
  setMotionTextState();
}, { passive: true });
setHeroLogoState();
setMotionTextState();

if (contactForm) {
  const status = contactForm.querySelector("[data-form-status]");
  const submitButton = contactForm.querySelector('button[type="submit"]');
  const submitLabel = submitButton?.textContent;
  const successUrl = new URL(contactForm.dataset.successUrl || "confirmation/", window.location.href);
  if (successUrl.protocol === "file:" && successUrl.pathname.endsWith("/")) {
    successUrl.pathname += "index.html";
  }
  let isSubmitting = false;
  const SERVICE_ID = "service_6ako0fv";
  const TEMPLATE_ID = "template_rqhujvf";
  const PUBLIC_KEY = "wY9izdJjB7ZjNDmE8";

  const setFormStatus = (message, state) => {
    if (!status) {
      return;
    }

    status.textContent = message;
    status.dataset.state = state;
    status.hidden = !message;
  };

  contactForm.dataset.formReady = "true";

  contactForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (isSubmitting) {
      return;
    }

    if (!contactForm.checkValidity()) {
      setFormStatus("Veuillez remplir les champs obligatoires avant d'envoyer la demande.", "error");
      contactForm.reportValidity();
      return;
    }

    isSubmitting = true;
    setFormStatus("", "");
    contactForm.setAttribute("aria-busy", "true");

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = "Envoi en cours\u2026";
    }

    try {
      if (!window.emailjs) {
        throw new Error("EmailJS n'est pas charge.");
      }

      const formData = new FormData(contactForm);
      const templateParams = {
        nom: String(formData.get("nom") || "").trim(),
        entreprise: String(formData.get("entreprise") || "").trim(),
        courriel: String(formData.get("courriel") || "").trim(),
        telephone: String(formData.get("telephone") || "").trim(),
        description: String(formData.get("description") || "").trim(),
        temps: new Date().toLocaleString("fr-CA", {
          dateStyle: "long",
          timeStyle: "short"
        })
      };

      await emailjs.send(SERVICE_ID, TEMPLATE_ID, templateParams, PUBLIC_KEY);

      contactForm.reset();
      window.location.assign(successUrl.href);
    } catch (error) {
      isSubmitting = false;
      contactForm.removeAttribute("aria-busy");
      setFormStatus("Une erreur est survenue. Veuillez r\u00e9essayer ou \u00e9crire directement \u00e0 info@visionaltitude.ca.", "error");
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.textContent = submitLabel;
      }
    }
  });

  window.addEventListener("pageshow", (event) => {
    if (!event.persisted) {
      return;
    }
    isSubmitting = false;
    contactForm.removeAttribute("aria-busy");
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = submitLabel;
    }
  });
}

document.querySelectorAll("[data-case-study-grid]").forEach((grid) => {
  const cards = [...grid.querySelectorAll(":scope > .case-card")];
  const button = grid.closest(".case-study-section")?.querySelector("[data-case-study-more]");
  const hiddenCards = cards.slice(6);

  if (!button || hiddenCards.length === 0) {
    return;
  }

  const setExpanded = (expanded) => {
    hiddenCards.forEach((card) => {
      card.hidden = !expanded;
      card.classList.toggle("is-visible", expanded);
    });
    button.textContent = expanded ? "Afficher moins" : "Afficher plus";
    button.setAttribute("aria-expanded", String(expanded));
  };

  setExpanded(false);
  button.hidden = false;

  button.addEventListener("click", () => {
    const shouldExpand = button.getAttribute("aria-expanded") !== "true";
    setExpanded(shouldExpand);

    if (shouldExpand) {
      window.requestAnimationFrame(() => {
        hiddenCards[0]?.focus({ preventScroll: true });
      });
    }
  });
});

const revealElements = [...document.querySelectorAll(".reveal")]
  .filter((element) => !firstPageSection?.contains(element));

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });

  revealElements.forEach((element) => observer.observe(element));
} else {
  revealElements.forEach((element) => element.classList.add("is-visible"));
}

document.querySelectorAll("[data-footer-paged]").forEach((footerColumn) => {
  const pages = Array.from(footerColumn.querySelectorAll("[data-footer-page]")).sort(
    (a, b) => Number(a.dataset.footerPage) - Number(b.dataset.footerPage)
  );
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  let currentPageIndex = pages.findIndex((page) => page.classList.contains("is-active"));

  if (pages.length < 2) {
    return;
  }

  if (currentPageIndex < 0) {
    currentPageIndex = 0;
  }

  const showPage = (pageIndex, direction) => {
    if (pageIndex < 0 || pageIndex >= pages.length || pageIndex === currentPageIndex) {
      return;
    }

    const activePage = pages[pageIndex];
    pages.forEach((page, index) => {
      if (index !== pageIndex) {
        page.hidden = true;
        page.classList.remove("is-active", "is-moving-down", "is-moving-up");
      }
    });
    activePage.hidden = false;
    activePage.classList.remove("is-moving-down", "is-moving-up");

    if (!prefersReducedMotion) {
      activePage.classList.add(direction === "down" ? "is-moving-down" : "is-moving-up");
    }

    activePage.classList.add("is-active");
    currentPageIndex = pageIndex;
  };

  footerColumn.querySelectorAll("[data-footer-next]").forEach((button) => {
    button.addEventListener("click", () => showPage(currentPageIndex + 1, "down"));
  });

  footerColumn.querySelectorAll("[data-footer-prev]").forEach((button) => {
    button.addEventListener("click", () => showPage(currentPageIndex - 1, "up"));
  });
});

document.querySelectorAll("[data-service-carousel]").forEach((carousel) => {
  const slides = [...carousel.querySelectorAll("[data-service-slide]")];
  const previous = carousel.querySelector("[data-service-prev]");
  const next = carousel.querySelector("[data-service-next]");
  const current = carousel.querySelector("[data-service-current]");
  const total = carousel.querySelector("[data-service-total]");

  if (!slides.length || !previous || !next) {
    return;
  }

  let activeIndex = Math.max(0, slides.findIndex((slide) => slide.classList.contains("is-active")));
  let touchStartX = 0;

  const loadFrame = (slide) => {
    const frame = slide.querySelector("iframe[data-src]");
    if (frame && !frame.src) {
      frame.src = frame.dataset.src;
    }
  };

  const stopFrame = (slide) => {
    const frame = slide.querySelector("iframe[src]");
    if (frame) {
      frame.dataset.src = frame.src;
      frame.removeAttribute("src");
    }
  };

  const showSlide = (nextIndex) => {
    const normalizedIndex = (nextIndex + slides.length) % slides.length;
    slides.forEach((slide, index) => {
      const isActive = index === normalizedIndex;
      if (!isActive) {
        stopFrame(slide);
      }
      slide.hidden = !isActive;
      slide.classList.toggle("is-active", isActive);
      slide.setAttribute("aria-hidden", String(!isActive));
    });
    activeIndex = normalizedIndex;
    loadFrame(slides[activeIndex]);
    if (current) {
      current.textContent = String(activeIndex + 1).padStart(2, "0");
    }
  };

  if (total) {
    total.textContent = String(slides.length).padStart(2, "0");
  }
  slides.forEach((slide, index) => slide.setAttribute("aria-hidden", String(index !== activeIndex)));
  loadFrame(slides[activeIndex]);

  previous.addEventListener("click", () => showSlide(activeIndex - 1));
  next.addEventListener("click", () => showSlide(activeIndex + 1));

  carousel.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      showSlide(activeIndex - 1);
    }
    if (event.key === "ArrowRight") {
      event.preventDefault();
      showSlide(activeIndex + 1);
    }
  });

  carousel.addEventListener("touchstart", (event) => {
    touchStartX = event.changedTouches[0].clientX;
  }, { passive: true });

  carousel.addEventListener("touchend", (event) => {
    const distance = event.changedTouches[0].clientX - touchStartX;
    if (Math.abs(distance) > 48) {
      showSlide(activeIndex + (distance < 0 ? 1 : -1));
    }
  }, { passive: true });
});

document.querySelectorAll("[data-partner-widget]").forEach((widget) => {
  const toggle = widget.querySelector("[data-partner-toggle]");
  const panel = widget.querySelector("[data-partner-panel]");

  if (!toggle || !panel) {
    return;
  }

  const canHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  let closeTimer;
  let hideTimer;

  const queueClose = () => {
    window.clearTimeout(closeTimer);
    closeTimer = window.setTimeout(() => closePanel({ restoreFocus: false }), 180);
  };

  const openPanel = () => {
    window.clearTimeout(closeTimer);
    window.clearTimeout(hideTimer);
    panel.hidden = false;
    window.requestAnimationFrame(() => {
      panel.classList.add("is-open");
      widget.classList.add("is-open");
    });
    toggle.setAttribute("aria-expanded", "true");
  };

  const closePanel = ({ restoreFocus = true } = {}) => {
    panel.classList.remove("is-open");
    widget.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    window.clearTimeout(hideTimer);
    hideTimer = window.setTimeout(() => {
      if (!panel.classList.contains("is-open")) {
        panel.hidden = true;
      }
    }, 280);

    if (restoreFocus) {
      toggle.focus({ preventScroll: true });
    }
  };

  if (canHover) {
    widget.addEventListener("mouseenter", openPanel);
    widget.addEventListener("mouseleave", queueClose);
    widget.addEventListener("focusin", openPanel);
    widget.addEventListener("focusout", (event) => {
      if (!widget.contains(event.relatedTarget)) {
        closePanel({ restoreFocus: false });
      }
    });
  } else {
    toggle.addEventListener("click", () => {
      if (panel.hidden) {
        openPanel();
      } else {
        closePanel();
      }
    });
  }

  document.addEventListener("click", (event) => {
    if (!panel.hidden && !widget.contains(event.target)) {
      closePanel({ restoreFocus: false });
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !panel.hidden) {
      closePanel();
    }
  });
});
